"""
Modulateur en anneaux intelligent
---------------------------------

Dans ce travail, vous devez créer une classe produisant un effet de modulation
en anneaux [1] dont la fréquence de l'oscillateur modulant est fonction de la
fréquence fondamentale du signal à moduler.

Votre classe doit d'abord effectuer un suivi de la fréquence fondamentale (pitch
tracker) du signal d'entrée, puis utiliser le resultat de ce suivi de fréquence
pour contrôler la fréquence de l'oscillateur modulant ce même signal d'entrée.

Votre classe doit avoir des arguments pour contrôler:

- Le signal audio à moduler.
- Un ratio appliqué à la fréquence analysée (pour que l'oscillateur modulant soit
  à l'octave en dessous par exemple). 
- La balance entre le signal original et le signal modulé.
- La forme d'onde de l'oscillateur modulant.

Doivent être présentes les méthodes suivantes:

out(self, chnl) : pour envoyer le signal audio vers un haut-parleur spécifique.
sig(self) : pour récupérer le signal audio à des fins de post-traitement.

Utilisez le son "flute_irlandaise.aif" pour tester votre classe.

[1] La modulation en anneaux est le résultat de la multiplication de deux signaux bipolaires,
avec comme spectre de sortie la somme et la différence du contenu spectral des deux signaux.

"""
from pyo import *

s = Server().boot()


son = "flute_irlandaise.aif"





s.gui(locals())